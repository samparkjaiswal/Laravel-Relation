<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Supplier;

class OrderController extends Controller
{
    public function hasonethrough($id)
    {
        $bysupplier = Supplier::with('order')->where('id',$id)->first();  //use this method this is  write approach
      
      
       dd($bysupplier);
    }
}
