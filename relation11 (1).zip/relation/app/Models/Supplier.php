<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    use HasFactory;
    protected $table = 'suppliers';

    public function order()
    {
        return $this->hasOneThrough(
            Order::class,   //final model name(which data we want to access)
            Product::class, //middle model name(which through final table(order) data will be access)
            'sid',          //foreign key of supplier table(1st table who data access) in Product table(middle table)
            'pid',          //foreign key of product table(middle table which through data access) in Order table(final table)
            'id',           //local key('primary key') of supplier(initial table)
            'id'            //local key('primary key') of product(middle table)
        );
    }
}
