<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Bike;

class RelationController extends Controller
{
//     public function show($id)
//     {
   

//       //  $bycus = Customer::find($id);
       
//      //  $bybike = Bike::find($id)->customer;



//      $bybike = Bike::with('customer')->where('id',$id)->first();  //use this method this is  write approach
      
      
//        dd($bybike);


//    // $bike = $bycus->bike;
//      // dd($bike->bikename);
//     //  $arr = [$bycus->id,$bycus->cusname,$bike->bikename];  //both way we access data using relationship

//     //  $arr = [$bike->id,$bycus->cusname,$bike->bikename];  //both way we access data using relationship

//       // dd($arr);
    
       
//     }

//     public function hasmany($id)
//     {
//         $bybike = Customer::with('manybike')->where('id',$id)->get();  //use this method this is  write approach
      
      
//        dd($bybike);
//     }

    public function manytomany($id)
    {
      $bybike = Customer::with('Bike')->where('id',$id)->get();

     

     //   $bybike = Bike::with('Customer')->where('id',$id)->get();
       // dd($bybike);

       return $bybike;

       //return  $bybike->pivot->created_at; it will be ask to sir there an error

     

    }
}
