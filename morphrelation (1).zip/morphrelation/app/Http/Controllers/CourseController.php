<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function morphmanytomany($id)
    {
      // $data = Post::with('imagesofmany')->where('id',$id)->get(); 
      $data = Comment::with('imagesofmany')->where('id',$id)->get(); 
      dd($data);
    }
}
