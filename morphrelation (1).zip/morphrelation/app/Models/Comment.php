<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    use HasFactory;

  //  protected $table ='comments';

//     public function images()
//     {
//         return $this->morphOne(Image::class, 'imageable');
//     }

    public function imagesmany()
    {
        return $this->morphMany(Image::class, 'imageable');
    }

    public function imagesofmany()
    {
      //  return $this->morphOne('App\Models\Image', 'imageable')->latestOfMany();
        return $this->morphOne('App\Models\Image', 'imageable')->oldestOfMany(); //it's use for show letest/oldest one data
    }
 }
