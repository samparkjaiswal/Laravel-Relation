<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;
  //  protected $table ='posts';

    // public function images()
    // {
    //     return $this->morphOne('App\Models\Image', 'imageable');
    // }

    public function imagesmany()
    {
        return $this->morphMany('App\Models\Image', 'imageable');
    }

    public function imagesofmany()
    {
        //return $this->morphOne('App\Models\Image', 'imageable')->latestOfMany();
        return $this->morphOne('App\Models\Image', 'imageable')->oldestOfMany(); //it's use for show letest/oldest one data
    }
}
